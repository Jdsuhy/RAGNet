import torch
import torch.nn as nn
import torch.nn.functional as F

from models import GATConv


class RelationAwareHeteroLayer(nn.Module):
    def __init__(self, in_dim, out_dim, num_rna_views, num_circ_views, num_rna, num_circRNA):
        super(RelationAwareHeteroLayer, self).__init__()

        self.num_rna = num_rna
        self.num_circRNA = num_circRNA
        self.num_rna_views = num_rna_views
        self.num_circ_views = num_circ_views

        self.rr_convs = nn.ModuleList([
            GATConv(in_channels=in_dim, out_channels=out_dim)
            for _ in range(num_rna_views)
        ])

        self.cc_convs = nn.ModuleList([
            GATConv(in_channels=in_dim, out_channels=out_dim)
            for _ in range(num_circ_views)
        ])

        self.rc_conv = GATConv(in_channels=in_dim, out_channels=out_dim)

        self.rr_view_att = nn.Linear(out_dim, 1, bias=False)
        self.cc_view_att = nn.Linear(out_dim, 1, bias=False)

        self.rna_gate = nn.Sequential(
            nn.Linear(out_dim * 2, out_dim),
            nn.ReLU(),
            nn.Linear(out_dim, 1),
            nn.Sigmoid()
        )

        self.circ_gate = nn.Sequential(
            nn.Linear(out_dim * 2, out_dim),
            nn.ReLU(),
            nn.Linear(out_dim, 1),
            nn.Sigmoid()
        )

        if in_dim != out_dim:
            self.res_proj = nn.Linear(in_dim, out_dim, bias=False)
        else:
            self.res_proj = nn.Identity()

    def fuse_same_type_views(self, outputs, scorer):
        if len(outputs) == 1:
            return outputs[0]
        stack = torch.stack(outputs, dim=0)           # [V, N, D]
        score = scorer(stack).squeeze(-1)             # [V, N]
        weight = torch.softmax(score, dim=0).unsqueeze(-1)
        return (weight * stack).sum(dim=0)

    def forward(self, x, rr_edge_list, cc_edge_list, rc_edge):
        rr_outputs = [conv(x, edge) for conv, edge in zip(self.rr_convs, rr_edge_list)]
        cc_outputs = [conv(x, edge) for conv, edge in zip(self.cc_convs, cc_edge_list)]
        rc_output = self.rc_conv(x, rc_edge)

        rr_fused = self.fuse_same_type_views(rr_outputs, self.rr_view_att)
        cc_fused = self.fuse_same_type_views(cc_outputs, self.cc_view_att)

        residual = self.res_proj(x)

        # miRNA 节点
        homo_rna = rr_fused[:self.num_rna]
        hetero_rna = rc_output[:self.num_rna]
        gate_rna = self.rna_gate(torch.cat([homo_rna, hetero_rna], dim=1))
        out_rna = gate_rna * homo_rna + (1.0 - gate_rna) * hetero_rna + residual[:self.num_rna]
        out_rna = F.elu(out_rna)

        # circRNA 节点
        start = self.num_rna
        end = self.num_rna + self.num_circRNA
        homo_circ = cc_fused[start:end]
        hetero_circ = rc_output[start:end]
        gate_circ = self.circ_gate(torch.cat([homo_circ, hetero_circ], dim=1))
        out_circ = gate_circ * homo_circ + (1.0 - gate_circ) * hetero_circ + residual[start:end]
        out_circ = F.elu(out_circ)

        return torch.cat([out_rna, out_circ], dim=0)


class RAGNet(nn.Module):
    def __init__(self, num_rna, num_circRNA, num_rna_views, num_circ_views,
                 n_features=128, hidden_dim=64, n_layers=2, dropout=0.2):
        super(RAGNet, self).__init__()

        self.num_rna = num_rna
        self.num_circRNA = num_circRNA
        self.num_rna_views = num_rna_views
        self.num_circ_views = num_circ_views
        self.dropout = dropout

        # 多视角特征编码
        self.rna_view_encoders = nn.ModuleList([
            nn.Linear(num_rna, n_features, bias=False) for _ in range(num_rna_views)
        ])
        self.circ_view_encoders = nn.ModuleList([
            nn.Linear(num_circRNA, n_features, bias=False) for _ in range(num_circ_views)
        ])

        self.rna_view_att = nn.Linear(n_features, 1, bias=False)
        self.circ_view_att = nn.Linear(n_features, 1, bias=False)

        # 关系感知异构注意力编码层
        self.hetero_layers = nn.ModuleList()
        for i in range(n_layers):
            in_dim = n_features if i == 0 else hidden_dim
            self.hetero_layers.append(
                RelationAwareHeteroLayer(
                    in_dim=in_dim,
                    out_dim=hidden_dim,
                    num_rna_views=num_rna_views,
                    num_circ_views=num_circ_views,
                    num_rna=num_rna,
                    num_circRNA=num_circRNA
                )
            )

        # 双流解码
        self.struct_proj = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout)
        )

        self.semantic_proj = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Dropout(dropout)
        )

        self.decoder_gate = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1),
            nn.Sigmoid()
        )

        self.predictor = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim // 2, 1),
            nn.Sigmoid()
        )

    def fuse_views(self, encoded_views, scorer):
        if len(encoded_views) == 1:
            return encoded_views[0]
        stack = torch.stack(encoded_views, dim=0)      # [V, N, D]
        score = scorer(stack).squeeze(-1)              # [V, N]
        weight = torch.softmax(score, dim=0).unsqueeze(-1)
        return (weight * stack).sum(dim=0)

    def encode_multi_view(self, rna_views, circ_views):
        rna_encoded = []
        for encoder, view in zip(self.rna_view_encoders, rna_views):
            out = F.elu(encoder(view))
            rna_encoded.append(out)

        circ_encoded = []
        for encoder, view in zip(self.circ_view_encoders, circ_views):
            out = F.elu(encoder(view))
            circ_encoded.append(out)

        rna_fused = self.fuse_views(rna_encoded, self.rna_view_att)
        circ_fused = self.fuse_views(circ_encoded, self.circ_view_att)

        x = torch.cat([rna_fused, circ_fused], dim=0)
        x = F.dropout(x, p=self.dropout, training=self.training)
        return x

    def encode_graph(self, rna_views, circ_views, rr_edge_list, cc_edge_list, rc_edge):
        x = self.encode_multi_view(rna_views, circ_views)

        for layer in self.hetero_layers:
            x = layer(x, rr_edge_list, cc_edge_list, rc_edge)
            x = F.dropout(x, p=self.dropout, training=self.training)

        rna_emb = x[:self.num_rna]
        circ_emb = x[self.num_rna:self.num_rna + self.num_circRNA]
        return rna_emb, circ_emb

    def dual_stream_decode(self, rna_emb, circ_emb, pair_index):
        rows = pair_index[:, 0].long()
        cols = pair_index[:, 1].long()

        h_rna = rna_emb[rows]
        h_circ = circ_emb[cols]

        # 结构流
        structural_feat = h_rna * h_circ
        structural_feat = self.struct_proj(structural_feat)

        # 语义流
        semantic_feat = torch.cat([h_rna, h_circ], dim=1)
        semantic_feat = self.semantic_proj(semantic_feat)

        gate = self.decoder_gate(torch.cat([structural_feat, semantic_feat], dim=1))
        fused = gate * structural_feat + (1.0 - gate) * semantic_feat

        score = self.predictor(fused)
        return score

    def forward(self, rna_views, circ_views, rr_edge_list, cc_edge_list, rc_edge, pair_index):
        rna_emb, circ_emb = self.encode_graph(
            rna_views, circ_views, rr_edge_list, cc_edge_list, rc_edge
        )
        score = self.dual_stream_decode(rna_emb, circ_emb, pair_index)
        return score