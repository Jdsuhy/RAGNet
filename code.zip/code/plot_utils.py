"""
plot_utils.py
-------------
通用 ROC/PR 曲线绘制工具，可独立用于任意模型。

使用方法：
    from plot_utils import ROCPRPlotter

    # 每折结束后收集结果
    fold_plot_results = []
    fold_plot_results.append({
        "y_true":   valid_label,      # numpy array，真实标签 0/1
        "y_scores": valid_score,      # numpy array，预测分数 ∈ (0,1)
        "auc":      metric[0],        # float，AUC 小数（如 0.9687）
        "aupr":     metric[1],        # float，AUPR 小数（如 0.9521）
        "fold":     fold_id,          # int，折编号（1-based）
    })

    # 5折跑完后调用绘图
    plotter = ROCPRPlotter(save_dir="./figures")
    plotter.plot_5fold_curves(
        fold_plot_results,
        model_name="YourModel",
        show_mean=True,
    )
"""

import os
import datetime
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.patches import ConnectionPatch
from mpl_toolkits.axes_grid1.inset_locator import inset_axes
from matplotlib.font_manager import FontProperties
from sklearn.metrics import roc_curve, precision_recall_curve


class ROCPRPlotter:
    """
    5折交叉验证 ROC/PR 曲线绘制器。

    功能：
      - 绘制每折曲线 + 均值曲线
      - 局部放大框（ROC 左上角 / PR 右上角）
      - 自动保存为高分辨率 PNG

    参数：
      save_dir : 图片保存目录，不存在时自动创建
    """

    FOLD_COLORS = ["#4E79A7", "#F28E2B", "#E15759", "#76B7B2", "#59A14F"]
    BASELINE_COLOR = "#8C8C8C"
    MEAN_COLOR = "#B07AA1"

    def __init__(self, save_dir: str = "figures"):
        self.save_dir = save_dir
        os.makedirs(save_dir, exist_ok=True)

    def _compute_mean_curve(self, fold_results, curve_type="roc"):
        """计算各折曲线的均值与标准差。"""
        common_x = np.linspace(0, 1, 100)
        y_list, metric_vals = [], []

        for r in fold_results:
            y_true, y_scores = r["y_true"], r["y_scores"]
            if curve_type == "roc":
                fpr, tpr, _ = roc_curve(y_true, y_scores)
                y_list.append(np.interp(common_x, fpr, tpr))
                metric_vals.append(r.get("auc", 0.0))
            else:
                prec, rec, _ = precision_recall_curve(y_true, y_scores)
                y_list.append(np.interp(common_x, rec[::-1], prec[::-1]))
                metric_vals.append(r.get("aupr", 0.0))

        return (
            common_x,
            np.mean(y_list, axis=0),
            np.std(y_list, axis=0),
            float(np.mean(metric_vals))
        )

    def _add_legend_with_tick_font(self, ax, fontsize=None, **kw):
        """使用与坐标轴刻度一致的字体渲染图例。"""
        ticklabels = ax.get_yticklabels()
        fp = ticklabels[0].get_fontproperties() if ticklabels else ax.yaxis.label.get_fontproperties()
        size = fontsize if fontsize else (ticklabels[0].get_fontsize() if ticklabels else 9)
        return ax.legend(
            prop=FontProperties(
                family=fp.get_family(),
                style=fp.get_style(),
                weight=fp.get_weight(),
                size=size
            ),
            **kw
        )

    def plot_5fold_curves(self, fold_results, model_name="Model",
                          timestamp=None, show_mean=True):
        """
        绘制 5 折 ROC + PR 曲线并保存。

        参数：
          fold_results : list of dict，每个 dict 包含：
                           - y_true   : numpy array，真实标签
                           - y_scores : numpy array，预测分数
                           - auc      : float，AUC 小数（如 0.9687）
                           - aupr     : float，AUPR 小数（如 0.9521）
                           - fold     : int，折编号
          model_name   : str，图标题和文件名中显示的模型名称
          timestamp    : str 或 None，文件名时间戳，None 时自动生成
          show_mean    : bool，是否绘制均值曲线

        返回：
          save_path : str，保存的图片路径
        """
        if timestamp is None:
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")

        roc_curves, pr_curves = [], []

        for r in fold_results:
            fpr, tpr, _ = roc_curve(r["y_true"], r["y_scores"])
            roc_curves.append({
                "fpr": fpr,
                "tpr": tpr,
                "auc": r.get("auc", 0.0),
                "fold": r.get("fold", 0)
            })

            prec, rec, _ = precision_recall_curve(r["y_true"], r["y_scores"])
            pr_curves.append({
                "precision": prec,
                "recall": rec,
                "aupr": r.get("aupr", 0.0),
                "fold": r.get("fold", 0)
            })

        if show_mean:
            mean_fpr, mean_tpr, _, mean_auc = self._compute_mean_curve(fold_results, "roc")
            mean_rec, mean_prec, _, mean_aupr = self._compute_mean_curve(fold_results, "pr")

        fig, (ax_roc, ax_pr) = plt.subplots(1, 2, figsize=(12.6, 5.2))
        fig.subplots_adjust(wspace=0.25)
        ax_roc.set_box_aspect(0.75)
        ax_pr.set_box_aspect(0.75)

        # ROC 主图
        for idx, d in enumerate(roc_curves):
            ax_roc.plot(
                d["fpr"], d["tpr"],
                lw=1.0, alpha=0.6,
                color=self.FOLD_COLORS[idx % len(self.FOLD_COLORS)],
                label=f"Fold {d['fold']} (AUC={d['auc']:.4f})"
            )
        if show_mean:
            ax_roc.plot(
                mean_fpr, mean_tpr,
                lw=1.5, color=self.MEAN_COLOR,
                label=f"Mean (AUC={mean_auc:.4f})",
                zorder=5
            )

        ax_roc.set_xlabel("False Positive Rate")
        ax_roc.set_ylabel("True Positive Rate")
        ax_roc.set_title(f"ROC CMI-9905")
        ax_roc.grid(True, ls="--", alpha=0.35)
        ax_roc.set_xlim(0, 1)
        ax_roc.set_ylim(0.0, 1.01)

        # ROC 放大框
        x1r, x2r, y1r, y2r = 0.03, 0.23, 0.75, 0.97
        axins_roc = inset_axes(
            ax_roc, width="46%", height="46%",
            loc="lower right", borderpad=0,
            bbox_to_anchor=(0.03, 0.08, 0.93, 0.94),
            bbox_transform=ax_roc.transAxes
        )
        for idx, d in enumerate(roc_curves):
            axins_roc.plot(
                d["fpr"], d["tpr"],
                lw=1.0, alpha=0.6,
                color=self.FOLD_COLORS[idx % len(self.FOLD_COLORS)]
            )
        if show_mean:
            axins_roc.plot(
                mean_fpr, mean_tpr,
                lw=1.2, color=self.MEAN_COLOR, zorder=10
            )
        axins_roc.set_xlim(x1r, x2r)
        axins_roc.set_ylim(y1r, y2r)
        axins_roc.grid(True, ls="--", alpha=0.30)

        ax_roc.add_patch(
            plt.Rectangle(
                (x1r, y1r), x2r - x1r, y2r - y1r,
                fill=False, lw=1.0, ls=(0, (3, 2)),
                ec=self.BASELINE_COLOR
            )
        )
        fig.add_artist(ConnectionPatch(
            xyA=(x2r, y1r), coordsA=ax_roc.transData,
            xyB=(0.0, 1.0), coordsB=axins_roc.transAxes,
            lw=1.0, ls=(0, (3, 2)), color=self.BASELINE_COLOR
        ))

        # PR 主图
        for idx, d in enumerate(pr_curves):
            ax_pr.plot(
                d["recall"], d["precision"],
                lw=1.3, alpha=0.6,
                color=self.FOLD_COLORS[idx % len(self.FOLD_COLORS)],
                label=f"Fold {d['fold']} (AUPR={d['aupr']:.4f})"
            )
        if show_mean:
            ax_pr.plot(
                mean_rec, mean_prec,
                lw=1.5, color=self.MEAN_COLOR,
                label=f"Mean (AUPR={mean_aupr:.4f})",
                zorder=5
            )

        ax_pr.set_xlabel("Recall")
        ax_pr.set_ylabel("Precision")
        ax_pr.set_title(f"PR CMI-9905")
        ax_pr.grid(True, ls="--", alpha=0.35)
        ax_pr.set_xlim(0, 1)
        ax_pr.set_ylim(0, 1.01)

        # PR 放大框
        x1p, x2p, y1p, y2p = 0.75, 0.95, 0.78, 0.97
        axins_pr = inset_axes(
            ax_pr, width="46%", height="46%",
            loc="lower left", borderpad=0,
            bbox_to_anchor=(0.11, 0.08, 0.96, 0.94),
            bbox_transform=ax_pr.transAxes
        )
        for idx, d in enumerate(pr_curves):
            axins_pr.plot(
                d["recall"], d["precision"],
                lw=1.0, alpha=0.6,
                color=self.FOLD_COLORS[idx % len(self.FOLD_COLORS)]
            )
        if show_mean:
            axins_pr.plot(
                mean_rec, mean_prec,
                lw=1.2, color=self.MEAN_COLOR, zorder=10
            )
        axins_pr.set_xlim(x1p, x2p)
        axins_pr.set_ylim(y1p, y2p)
        axins_pr.grid(True, ls="--", alpha=0.30)

        ax_pr.add_patch(
            plt.Rectangle(
                (x1p, y1p), x2p - x1p, y2p - y1p,
                fill=False, lw=1.0, ls=(0, (3, 2)),
                ec=self.BASELINE_COLOR
            )
        )
        fig.add_artist(ConnectionPatch(
            xyA=(x1p, y1p), coordsA=ax_pr.transData,
            xyB=(1.0, 1.0), coordsB=axins_pr.transAxes,
            lw=1.0, ls=(0, (3, 2)), color=self.BASELINE_COLOR
        ))

        for ax in (ax_roc, ax_pr):
            ax.tick_params(axis="y", which="major", length=6.0)
            ax.tick_params(axis="y", which="minor", length=6.0)

        self._add_legend_with_tick_font(
            ax_roc,
            loc="upper right",
            bbox_to_anchor=(0.97, 0.88),
            handlelength=1.5,
            handletextpad=0.5,
            labelspacing=0.3,
            borderpad=0.3,
            framealpha=0.95,
            fontsize=9
        )
        self._add_legend_with_tick_font(
            ax_pr,
            loc="upper left",
            bbox_to_anchor=(0.10, 0.88),
            handlelength=1.5,
            handletextpad=0.5,
            labelspacing=0.3,
            borderpad=0.3,
            framealpha=0.95,
            fontsize=9
        )

        save_path = os.path.join(
            self.save_dir,
            f"ROC_PR_5fold_{model_name}_{timestamp}.png"
        )
        fig.savefig(save_path, dpi=300, bbox_inches="tight")
        plt.close(fig)
        print(f"\n[Plot] ROC+PR 曲线已保存 → {save_path}")
        return save_path