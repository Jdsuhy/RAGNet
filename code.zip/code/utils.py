import os
import random
import numpy as np
import torch
from scipy.sparse import coo_matrix
from sklearn import metrics
from sklearn.model_selection import KFold

_THREADS_CONFIGURED = False


def set_seed(seed=42):
    """固定随机种子，尽量保证 CPU 版本多次运行结果一致。"""
    global _THREADS_CONFIGURED

    os.environ["PYTHONHASHSEED"] = str(seed)
    os.environ["CUBLAS_WORKSPACE_CONFIG"] = ":4096:8"

    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    # 即使本版本强制 CPU，也保留 CUDA seed，不影响 CPU 运行。
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)

    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

    # 尽量启用确定性算法。warn_only=True 可避免部分 PyG 算子直接报错。
    try:
        torch.use_deterministic_algorithms(True, warn_only=True)
    except Exception:
        pass

    # CPU 最终复现实验建议固定为单线程，避免多线程规约带来的极小浮动。
    # set_num_interop_threads 只能在程序早期设置一次，因此加全局保护。
    if not _THREADS_CONFIGURED:
        try:
            torch.set_num_threads(1)
        except Exception:
            pass
        try:
            torch.set_num_interop_threads(1)
        except Exception:
            pass
        _THREADS_CONFIGURED = True


def calculate_score(label, output):
    auc = metrics.roc_auc_score(label, output)
    precision_curve, recall_curve, _ = metrics.precision_recall_curve(label, output)
    aupr = metrics.auc(recall_curve, precision_curve)
    pred = np.where(output > 0.5, 1, 0)

    accuracy = metrics.accuracy_score(label, pred)
    precision = metrics.precision_score(label, pred)
    f1_score = metrics.f1_score(label, pred)
    mcc = metrics.matthews_corrcoef(label, pred)

    return auc, aupr, accuracy, precision, f1_score, mcc


def load_multi_view_bundle(data_dir):
    file_path = os.path.join(data_dir, 'multi_view_graph_data.npz')
    bundle = np.load(file_path, allow_pickle=True)

    num_rna_views = int(bundle['num_rna_views'][0])
    num_circ_views = int(bundle['num_circ_views'][0])
    interaction = bundle['interaction']

    rna_views = [bundle[f'rna_view_{i}'].astype(np.float32) for i in range(num_rna_views)]
    circ_views = [bundle[f'circ_view_{i}'].astype(np.float32) for i in range(num_circ_views)]
    rr_edges = [bundle[f'rr_edge_{i}'].astype(np.int64) for i in range(num_rna_views)]
    cc_edges = [bundle[f'cc_edge_{i}'].astype(np.int64) for i in range(num_circ_views)]
    rc_edge = bundle['rc_edge'].astype(np.int64)

    return interaction, rna_views, circ_views, rr_edges, cc_edges, rc_edge


def load_data(data_dir, k_index, random_seed=10):
    interaction, rna_views, circ_views, rr_edges, cc_edges, rc_edge = load_multi_view_bundle(data_dir)

    coo_inter = coo_matrix(interaction)
    pos_data = np.hstack((coo_inter.row[:, np.newaxis], coo_inter.col[:, np.newaxis]))

    # 保持你原始代码的负样本策略不变：replace=True。
    # 这样只修改复现性设置，不改变原实验设计。
    rng = np.random.default_rng(random_seed)
    neg_candidates = np.vstack(np.where(interaction == 0)).transpose()
    neg_indices = rng.choice(len(neg_candidates), size=pos_data.shape[0], replace=True)
    neg_data = neg_candidates[neg_indices]

    skf = KFold(n_splits=5, shuffle=True, random_state=random_seed)

    train_pos = test_pos = train_neg = test_neg = None
    for fold_index, (train_index, test_index) in enumerate(skf.split(pos_data)):
        if fold_index == k_index:
            train_pos = pos_data[train_index]
            test_pos = pos_data[test_index]
            train_neg = neg_data[train_index]
            test_neg = neg_data[test_index]
            break

    return interaction, rna_views, circ_views, rr_edges, cc_edges, rc_edge, train_pos, test_pos, train_neg, test_neg
