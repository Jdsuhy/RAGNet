# main_cpu_fixed.py
import argparse
import os
import numpy as np
import pandas as pd
import torch
from sklearn import metrics

from RAGNet import RAGNet
from utils import set_seed, calculate_score, load_data
from plot_utils import ROCPRPlotter

# =============================
# 强制使用 CPU，保证最终结果更稳定
# =============================
device = torch.device("cpu")


def train_one_epoch(model, optimizer, loss_function,
                    rna_views, circ_views, rr_edges, cc_edges, rc_edge,
                    train_data, train_label):
    model.train()
    optimizer.zero_grad()

    train_output = model(
        rna_views, circ_views,
        rr_edges, cc_edges, rc_edge,
        train_data
    )
    train_loss = loss_function(train_output, train_label)

    train_auc = metrics.roc_auc_score(
        train_label.detach().cpu().numpy(),
        train_output.detach().cpu().numpy()
    )
    precision_curve, recall_curve, _ = metrics.precision_recall_curve(
        train_label.detach().cpu().numpy(),
        train_output.detach().cpu().numpy()
    )
    train_aupr = metrics.auc(recall_curve, precision_curve)

    train_loss.backward()
    optimizer.step()

    return float(train_loss.detach().cpu().numpy()), float(train_auc), float(train_aupr)


def evaluate(model, loss_function,
             rna_views, circ_views, rr_edges, cc_edges, rc_edge,
             test_data, test_label):
    model.eval()
    with torch.no_grad():
        test_output = model(
            rna_views, circ_views,
            rr_edges, cc_edges, rc_edge,
            test_data
        )
        test_loss = loss_function(test_output, test_label)
        test_auc, test_aupr, test_accuracy, test_precision, test_f1_score, test_mcc = calculate_score(
            test_label.detach().cpu().numpy(),
            test_output.detach().cpu().numpy()
        )

    return {
        'loss': float(test_loss.detach().cpu().numpy()),
        'auc': float(test_auc),
        'aupr': float(test_aupr),
        'acc': float(test_accuracy),
        'precision': float(test_precision),
        'f1': float(test_f1_score),
        'mcc': float(test_mcc),
        'y_true': test_label.detach().cpu().numpy().flatten(),
        'y_scores': test_output.detach().cpu().numpy().flatten()
    }


def run_one_fold(fold, args):
    print(f'\n{"=" * 20} Fold {fold + 1}/5 {"=" * 20}')

    # 每折使用固定但不同的初始化种子：seed, seed+1, ..., seed+4
    set_seed(args.seed + fold)

    (
        interaction,
        rna_views_np,
        circ_views_np,
        rr_edges_np,
        cc_edges_np,
        rc_edge_np,
        train_pos_data,
        test_pos_data,
        train_neg_data,
        test_neg_data
    ) = load_data(data_dir=args.data_dir, k_index=fold, random_seed=args.seed)

    train_data = np.vstack([train_pos_data, train_neg_data])
    test_data = np.vstack([test_pos_data, test_neg_data])

    train_label = np.vstack([
        np.ones((train_pos_data.shape[0], 1)),
        np.zeros((train_neg_data.shape[0], 1))
    ]).astype(np.float32)

    test_label = np.vstack([
        np.ones((test_pos_data.shape[0], 1)),
        np.zeros((test_neg_data.shape[0], 1))
    ]).astype(np.float32)

    rna_views = [torch.tensor(x, dtype=torch.float32, device=device) for x in rna_views_np]
    circ_views = [torch.tensor(x, dtype=torch.float32, device=device) for x in circ_views_np]
    rr_edges = [torch.tensor(x, dtype=torch.long, device=device) for x in rr_edges_np]
    cc_edges = [torch.tensor(x, dtype=torch.long, device=device) for x in cc_edges_np]
    rc_edge = torch.tensor(rc_edge_np, dtype=torch.long, device=device)

    train_data = torch.tensor(train_data, dtype=torch.long, device=device)
    test_data = torch.tensor(test_data, dtype=torch.long, device=device)
    train_label = torch.tensor(train_label, dtype=torch.float32, device=device)
    test_label = torch.tensor(test_label, dtype=torch.float32, device=device)

    num_rna = rna_views[0].shape[0]
    num_circ = circ_views[0].shape[0]

    model = RAGNet(
        num_rna=num_rna,
        num_circRNA=num_circ,
        num_rna_views=len(rna_views),
        num_circ_views=len(circ_views),
        n_features=args.n_features,
        hidden_dim=args.hid_r,
        n_layers=args.n_layers,
        dropout=args.dropout
    ).to(device)

    optimizer = torch.optim.Adam(model.parameters(), lr=args.learning_rate, weight_decay=args.weight_decay)
    loss_function = torch.nn.BCELoss()

    for epoch in range(args.num_epochs):
        train_loss, train_auc, train_aupr = train_one_epoch(
            model=model,
            optimizer=optimizer,
            loss_function=loss_function,
            rna_views=rna_views,
            circ_views=circ_views,
            rr_edges=rr_edges,
            cc_edges=cc_edges,
            rc_edge=rc_edge,
            train_data=train_data,
            train_label=train_label
        )

        if (epoch + 1) % args.eval_interval == 0 or (epoch + 1) == args.num_epochs:
            print(
                f'Fold {fold + 1} Epoch {epoch + 1:03d} | '
                f'Train Loss: {train_loss:.4f}, '
                f'Train AUC: {train_auc:.4f}, '
                f'Train AUPR: {train_aupr:.4f}'
            )

    final_result = evaluate(
        model=model,
        loss_function=loss_function,
        rna_views=rna_views,
        circ_views=circ_views,
        rr_edges=rr_edges,
        cc_edges=cc_edges,
        rc_edge=rc_edge,
        test_data=test_data,
        test_label=test_label
    )

    print(
        f'Fold {fold + 1} Final Test -> '
        f'Loss: {final_result["loss"]:.4f}, '
        f'AUC: {final_result["auc"]:.4f}, '
        f'AUPR: {final_result["aupr"]:.4f}, '
        f'ACC: {final_result["acc"]:.4f}, '
        f'Precision: {final_result["precision"]:.4f}, '
        f'F1: {final_result["f1"]:.4f}, '
        f'MCC: {final_result["mcc"]:.4f}'
    )

    fold_plot_result = {
        "y_true": final_result["y_true"],
        "y_scores": final_result["y_scores"],
        "auc": final_result["auc"],
        "aupr": final_result["aupr"],
        "fold": fold + 1
    }

    return final_result, fold_plot_result


def summarize_results(results):
    metric_names = ['auc', 'aupr', 'acc', 'precision', 'f1', 'mcc']
    display_names = {
        'auc': 'AUC',
        'aupr': 'AUPR',
        'acc': 'ACC',
        'precision': 'Precision',
        'f1': 'F1',
        'mcc': 'MCC'
    }

    print(f'\n{"=" * 20} 5-Fold Results {"=" * 20}')
    for i, result in enumerate(results):
        print(
            f'Fold {i + 1}: '
            f'AUC={result["auc"]:.4f}, '
            f'AUPR={result["aupr"]:.4f}, '
            f'ACC={result["acc"]:.4f}, '
            f'Precision={result["precision"]:.4f}, '
            f'F1={result["f1"]:.4f}, '
            f'MCC={result["mcc"]:.4f}'
        )

    print(f'\n{"=" * 20} Mean ± Std {"=" * 20}')
    for name in metric_names:
        values = np.array([r[name] for r in results], dtype=np.float32)
        print(f'{display_names[name]}: {values.mean():.4f} ± {values.std():.4f}')


def save_results_csv(results, args):
    result_df = pd.DataFrame([
        {
            "Fold": i + 1,
            "AUC": r["auc"],
            "AUPR": r["aupr"],
            "ACC": r["acc"],
            "Precision": r["precision"],
            "F1": r["f1"],
            "MCC": r["mcc"]
        }
        for i, r in enumerate(results)
    ])

    mean_row = {
        "Fold": "Mean",
        "AUC": result_df["AUC"].mean(),
        "AUPR": result_df["AUPR"].mean(),
        "ACC": result_df["ACC"].mean(),
        "Precision": result_df["Precision"].mean(),
        "F1": result_df["F1"].mean(),
        "MCC": result_df["MCC"].mean()
    }

    std_row = {
        "Fold": "Std",
        "AUC": result_df["AUC"].std(ddof=0),
        "AUPR": result_df["AUPR"].std(ddof=0),
        "ACC": result_df["ACC"].std(ddof=0),
        "Precision": result_df["Precision"].std(ddof=0),
        "F1": result_df["F1"].std(ddof=0),
        "MCC": result_df["MCC"].std(ddof=0)
    }

    result_df = pd.concat(
        [result_df, pd.DataFrame([mean_row, std_row])],
        ignore_index=True
    )

    save_path = os.path.join(args.data_dir, f"RAGNet_5fold_results_seed{args.seed}_CPU.csv")
    result_df.to_csv(save_path, index=False, float_format="%.4f")
    print(f"\n[Result] 5-fold results saved to: {save_path}")
    return save_path


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--data-dir', type=str, default='./data/')
    parser.add_argument('--num-epochs', type=int, default=30)
    parser.add_argument('--hid-r', type=int, default=64)
    parser.add_argument('--n-layers', type=int, default=3)
    parser.add_argument('--n-features', type=int, default=128)
    parser.add_argument('--learning-rate', type=float, default=5e-4)
    parser.add_argument('--weight-decay', type=float, default=1e-5)
    parser.add_argument('--dropout', type=float, default=0.2)
    parser.add_argument('--eval-interval', type=int, default=10)
    parser.add_argument('--seed', type=int, default=42)
    args = parser.parse_args()

    set_seed(args.seed)
    print(f"[Info] Fixed seed: {args.seed}")
    print(f"[Info] Running device: {device}")

    all_results = []
    fold_plot_results = []

    for fold in range(5):
        fold_result, fold_plot_result = run_one_fold(fold, args)
        all_results.append(fold_result)
        fold_plot_results.append(fold_plot_result)

    summarize_results(all_results)
    save_results_csv(all_results, args)

    # 绘制 ROC + PR 曲线。timestamp 固定，避免每次输出文件名变化。
    plotter = ROCPRPlotter(save_dir=os.path.join(args.data_dir, "figures"))
    plotter.plot_5fold_curves(
        fold_plot_results,
        model_name="RAGNet_CPU",
        timestamp=f"seed{args.seed}_fixed"
    )
