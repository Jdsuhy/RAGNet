import os
import argparse
import numpy as np
import pandas as pd
from scipy.sparse import coo_matrix
from scipy.spatial.distance import cdist
from sklearn.cluster import DBSCAN

# =============================
# 命令行参数
# =============================
parser = argparse.ArgumentParser()
parser.add_argument('--data-dir', type=str, default='./data/', help='输入CSV文件目录')
parser.add_argument('--eps', type=float, default=0.5, help='DBSCAN eps参数')
parser.add_argument('--min-samples', type=int, default=3, help='DBSCAN min_samples参数')
parser.add_argument('--similarity-threshold', type=float, default=0.5, help='边阈值')
args = parser.parse_args()
input_dir = args.data_dir

# 输出目录
output_dir = os.path.join(input_dir, 'processed/')
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# =============================
# 多视角文件列表
# =============================
RNA_VIEW_FILES = [
    ('seq', 'mi_seq_similarity.csv'),
    ('exp', 'mi_exp_similarity.csv'),
    ('str', 'mi_str_similarity.csv'),
]

CIRC_VIEW_FILES = [
    ('seq', 'circ_seq_similarity.csv'),
    ('exp', 'circ_exp_similarity.csv'),
    ('str', 'circ_str_similarity.csv'),
]

# =============================
# 工具函数
# =============================
def read_square_matrix(file_path):
    mat = pd.read_csv(file_path, header=None).values
    return np.asarray(mat, dtype=np.float32)

def compute_gip(interaction, axis=0):
    X = interaction.T if axis == 0 else interaction
    sq_dists = cdist(X, X, metric='sqeuclidean')
    gamma = 1.0 / (np.mean(np.sum(X * X, axis=1)) + 1e-12)
    return np.exp(-gamma * sq_dists).astype(np.float32)

def dbscan_edges(sim_matrix, eps=0.5, min_samples=3, threshold=0.5, offset=0):
    """使用DBSCAN+阈值+超图生成边"""
    n = sim_matrix.shape[0]
    edges = []

    # DBSCAN 聚类
    clustering = DBSCAN(eps=eps, min_samples=min_samples, metric='precomputed')
    dist_matrix = 1.0 - sim_matrix  # 相似度转距离
    labels = clustering.fit_predict(dist_matrix)

    unique_labels = set(labels)
    for label in unique_labels:
        if label == -1:
            continue  # 噪声点
        cluster_idx = np.where(labels == label)[0]
        # 阈值保留高相似边
        for i in cluster_idx:
            for j in cluster_idx:
                if i >= j:
                    continue
                if sim_matrix[i, j] >= threshold:
                    edges.append([i + offset, j + offset])
                    edges.append([j + offset, i + offset])

    # 超图: cluster 内所有节点连接成超边
    for label in unique_labels:
        if label == -1:
            continue
        cluster_idx = np.where(labels == label)[0]
        for i in cluster_idx:
            for j in cluster_idx:
                if i >= j:
                    continue
                edges.append([i + offset, j + offset])
                edges.append([j + offset, i + offset])

    edges = np.unique(np.array(edges).T, axis=1).astype(np.int64)
    return edges

# =============================
# 读取已知关联
# =============================
association_file = os.path.join(input_dir, '9905pairs.csv')
association = pd.read_csv(association_file, header=None, names=['miRNA', 'circRNA'])
association['miRNA'] = association['miRNA'].astype(str).str.strip()
association['circRNA'] = association['circRNA'].astype(str).str.strip()
association = association.drop_duplicates().reset_index(drop=True)

miRNA_list = association['miRNA'].drop_duplicates().tolist()
circRNA_list = association['circRNA'].drop_duplicates().tolist()
num_miRNA = len(miRNA_list)
num_circRNA = len(circRNA_list)

miRNA_to_idx = {name: idx for idx, name in enumerate(miRNA_list)}
circRNA_to_idx = {name: idx for idx, name in enumerate(circRNA_list)}

interaction = np.zeros((num_miRNA, num_circRNA), dtype=np.float32)
rows = association['miRNA'].map(miRNA_to_idx).to_numpy()
cols = association['circRNA'].map(circRNA_to_idx).to_numpy()
interaction[rows, cols] = 1.0

# =============================
# 读取多视角矩阵
# =============================
rna_views = {name: read_square_matrix(os.path.join(input_dir, file)) for name, file in RNA_VIEW_FILES}
circ_views = {name: read_square_matrix(os.path.join(input_dir, file)) for name, file in CIRC_VIEW_FILES}

# 自动加入 GIP 视角
rna_views['gip'] = compute_gip(interaction, axis=1)
circ_views['gip'] = compute_gip(interaction, axis=0)

# =============================
# 构建同质边
# =============================
rr_edges = {name: dbscan_edges(mat, eps=args.eps, min_samples=args.min_samples,
                               threshold=args.similarity_threshold)
            for name, mat in rna_views.items()}
cc_edges = {name: dbscan_edges(mat, eps=args.eps, min_samples=args.min_samples,
                               threshold=args.similarity_threshold, offset=num_miRNA)
            for name, mat in circ_views.items()}

# =============================
# 构建异质边 miRNA <-> circRNA
# =============================
coo_inter = coo_matrix(interaction)
src_r = coo_inter.row
dst_c = coo_inter.col + num_miRNA
rc_edge_forward = np.stack([src_r, dst_c], axis=0)
rc_edge_backward = np.stack([dst_c, src_r], axis=0)
rc_edge = np.concatenate([rc_edge_forward, rc_edge_backward], axis=1).astype(np.int64)

# =============================
# 保存多视角图数据
# =============================
save_dict = {
    'interaction': interaction.astype(np.float32),
    'num_rna_views': np.array([len(rna_views)], dtype=np.int64),
    'num_circ_views': np.array([len(circ_views)], dtype=np.int64),
    'num_miRNA': np.array([num_miRNA], dtype=np.int64),
    'num_circRNA': np.array([num_circRNA], dtype=np.int64),
    'rc_edge': rc_edge,
}

for i, (name, mat) in enumerate(rna_views.items()):
    save_dict[f'rna_view_{i}'] = mat.astype(np.float32)
    save_dict[f'rr_edge_{i}'] = rr_edges[name]

for i, (name, mat) in enumerate(circ_views.items()):
    save_dict[f'circ_view_{i}'] = mat.astype(np.float32)
    save_dict[f'cc_edge_{i}'] = cc_edges[name]

np.savez_compressed(os.path.join(output_dir, 'multi_view_graph_data.npz'), **save_dict)

# =============================
# 输出信息
# =============================
print('Multi-view graph data saved successfully.')
print(f'RNA views: {list(rna_views.keys())}')
print(f'circRNA views: {list(circ_views.keys())}')
print(f'Total miRNA nodes: {num_miRNA}, circRNA nodes: {num_circRNA}')
print(f'Total rc_edge: {rc_edge.shape[1]}')
for i in range(len(rna_views)):
    print(f'rr_edge_{i} num: {rr_edges[list(rna_views.keys())[i]].shape[1]}')
for i in range(len(circ_views)):
    print(f'cc_edge_{i} num: {cc_edges[list(circ_views.keys())[i]].shape[1]}')